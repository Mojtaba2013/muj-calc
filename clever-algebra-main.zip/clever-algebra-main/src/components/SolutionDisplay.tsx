import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";

interface Step {
  description: string;
  expression: string;
}

interface SolutionDisplayProps {
  problem: string;
  steps: Step[];
  answer: string;
}

export const SolutionDisplay = ({ problem, steps, answer }: SolutionDisplayProps) => {
  return (
    <Card className="shadow-md animate-in fade-in slide-in-from-bottom-4 duration-500">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">Solution</CardTitle>
          <Badge variant="default" className="gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            Solved
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">Problem: <span className="font-mono text-foreground">{problem}</span></p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Steps:</h3>
          {steps.map((step, index) => (
            <div
              key={index}
              className="pl-6 border-l-2 border-primary/30 py-2 space-y-1 animate-in fade-in slide-in-from-left-2 duration-300"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <p className="text-sm font-medium text-muted-foreground">
                Step {index + 1}: {step.description}
              </p>
              <p className="font-mono text-lg">{step.expression}</p>
            </div>
          ))}
        </div>
        <div className="pt-4 border-t">
          <div className="bg-accent/10 rounded-lg p-4 border border-accent/20">
            <p className="text-sm font-semibold text-muted-foreground mb-1">Final Answer:</p>
            <p className="font-mono text-2xl font-bold text-accent">{answer}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
