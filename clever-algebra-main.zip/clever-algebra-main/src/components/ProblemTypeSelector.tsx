import { Button } from "@/components/ui/button";

export type ProblemType = "solve" | "simplify" | "factor" | "expand";

interface ProblemTypeSelectorProps {
  selected: ProblemType;
  onSelect: (type: ProblemType) => void;
}

const problemTypes: { value: ProblemType; label: string; description: string }[] = [
  { value: "solve", label: "Solve", description: "Solve equations" },
  { value: "simplify", label: "Simplify", description: "Simplify expressions" },
  { value: "factor", label: "Factor", description: "Factor polynomials" },
  { value: "expand", label: "Expand", description: "Expand expressions" },
];

export const ProblemTypeSelector = ({ selected, onSelect }: ProblemTypeSelectorProps) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {problemTypes.map((type) => (
        <Button
          key={type.value}
          variant={selected === type.value ? "default" : "outline"}
          onClick={() => onSelect(type.value)}
          className="flex flex-col items-center gap-1 h-auto py-4"
        >
          <span className="font-semibold text-sm">{type.label}</span>
          <span className="text-xs opacity-80">{type.description}</span>
        </Button>
      ))}
    </div>
  );
};
