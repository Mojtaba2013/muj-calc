import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calculator } from "lucide-react";

interface EquationInputProps {
  onSolve: (equation: string) => void;
  isLoading?: boolean;
}

export const EquationInput = ({ onSolve, isLoading }: EquationInputProps) => {
  const [equation, setEquation] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (equation.trim()) {
      onSolve(equation.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex gap-3">
        <Input
          type="text"
          value={equation}
          onChange={(e) => setEquation(e.target.value)}
          placeholder="Enter your equation (e.g., 2x + 5 = 13)"
          className="flex-1 text-lg py-6 bg-card"
          disabled={isLoading}
        />
        <Button
          type="submit"
          size="lg"
          disabled={!equation.trim() || isLoading}
          className="px-8"
        >
          <Calculator className="w-5 h-5 mr-2" />
          Solve
        </Button>
      </div>
      <div className="flex flex-wrap gap-2">
        <span className="text-sm text-muted-foreground">Quick examples:</span>
        {["2x + 5 = 13", "x^2 - 4", "3(x + 2)"].map((example) => (
          <Button
            key={example}
            type="button"
            variant="secondary"
            size="sm"
            onClick={() => setEquation(example)}
            disabled={isLoading}
          >
            {example}
          </Button>
        ))}
      </div>
    </form>
  );
};
