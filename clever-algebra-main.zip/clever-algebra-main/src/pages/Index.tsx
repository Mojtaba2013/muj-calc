import { useState } from "react";
import { Calculator } from "lucide-react";
import { ProblemTypeSelector, ProblemType } from "@/components/ProblemTypeSelector";
import { EquationInput } from "@/components/EquationInput";
import { SolutionDisplay } from "@/components/SolutionDisplay";
import { toast } from "sonner";
import {
  solveEquation,
  simplifyExpression,
  factorExpression,
  expandExpression,
} from "@/lib/algebra-solver";

const Index = () => {
  const [problemType, setProblemType] = useState<ProblemType>("solve");
  const [solution, setSolution] = useState<{
    problem: string;
    steps: Array<{ description: string; expression: string }>;
    answer: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSolve = (equation: string) => {
    setIsLoading(true);
    setSolution(null);

    // Simulate processing time for better UX
    setTimeout(() => {
      try {
        let result;
        
        switch (problemType) {
          case "solve":
            result = solveEquation(equation);
            break;
          case "simplify":
            result = simplifyExpression(equation);
            break;
          case "factor":
            result = factorExpression(equation);
            break;
          case "expand":
            result = expandExpression(equation);
            break;
        }

        setSolution({
          problem: equation,
          ...result,
        });
        
        toast.success("Solution found!");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "An error occurred");
      } finally {
        setIsLoading(false);
      }
    }, 500);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-primary-glow">
              <Calculator className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
                Algebra Solver
              </h1>
              <p className="text-sm text-muted-foreground">Master algebra with step-by-step solutions</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-8">
          {/* Problem Type Selection */}
          <section className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Choose Problem Type</h2>
            <ProblemTypeSelector selected={problemType} onSelect={setProblemType} />
          </section>

          {/* Input Section */}
          <section className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Enter Your Problem</h2>
            <EquationInput onSolve={handleSolve} isLoading={isLoading} />
          </section>

          {/* Solution Display */}
          {solution && (
            <section className="space-y-4">
              <SolutionDisplay
                problem={solution.problem}
                steps={solution.steps}
                answer={solution.answer}
              />
            </section>
          )}

          {/* Info Section */}
          {!solution && (
            <section className="text-center py-12 space-y-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 mx-auto flex items-center justify-center">
                <Calculator className="w-8 h-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Ready to solve!</h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Enter an equation or expression above and we'll show you step-by-step solutions
                </p>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16 py-8 bg-card/30">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Built for students and math enthusiasts • Step-by-step solutions • Learn as you solve</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
