import * as math from 'mathjs';

interface Step {
  description: string;
  expression: string;
}

interface AlgebraSolution {
  steps: Step[];
  answer: string;
}

const solveLinearEquation = (left: string, right: string): string => {
  try {
    // Parse and evaluate both sides
    const leftExpr = math.parse(left);
    const rightExpr = math.parse(right);
    
    // Try different values to find the solution
    // This is a simple numerical approach
    for (let x = -100; x <= 100; x += 0.5) {
      try {
        const leftVal = leftExpr.evaluate({ x });
        const rightVal = rightExpr.evaluate({ x });
        
        if (Math.abs(leftVal - rightVal) < 0.01) {
          return x.toString();
        }
      } catch {
        continue;
      }
    }
    
    return "No solution found";
  } catch {
    return "Unable to solve";
  }
};

export const solveEquation = (equation: string): AlgebraSolution => {
  try {
    // Parse the equation
    const [left, right] = equation.split('=').map(s => s.trim());
    
    if (!right) {
      throw new Error("Invalid equation format. Please use '=' sign.");
    }

    const steps: Step[] = [];
    
    // Original equation
    steps.push({
      description: "Original equation",
      expression: equation,
    });

    // Try to solve
    const solution = solveLinearEquation(left, right);
    
    // Create intermediate steps
    const simplified = math.simplify(`(${left}) - (${right})`);
    steps.push({
      description: "Move all terms to one side",
      expression: `${simplified.toString()} = 0`,
    });

    steps.push({
      description: "Solve for x",
      expression: `x = ${solution}`,
    });

    return {
      steps,
      answer: `x = ${solution}`,
    };
  } catch (error) {
    throw new Error("Could not solve equation. Please check your input.");
  }
};

export const simplifyExpression = (expression: string): AlgebraSolution => {
  try {
    const steps: Step[] = [];
    
    steps.push({
      description: "Original expression",
      expression: expression,
    });

    const simplified = math.simplify(expression);
    
    steps.push({
      description: "Combine like terms and simplify",
      expression: simplified.toString(),
    });

    return {
      steps,
      answer: simplified.toString(),
    };
  } catch (error) {
    throw new Error("Could not simplify expression. Please check your input.");
  }
};

export const factorExpression = (expression: string): AlgebraSolution => {
  try {
    const steps: Step[] = [];
    
    steps.push({
      description: "Original expression",
      expression: expression,
    });

    // Simple factoring using mathjs
    const parsed = math.parse(expression);
    const factored = math.simplify(parsed);
    
    steps.push({
      description: "Factor the expression",
      expression: factored.toString(),
    });

    return {
      steps,
      answer: factored.toString(),
    };
  } catch (error) {
    throw new Error("Could not factor expression. Please check your input.");
  }
};

export const expandExpression = (expression: string): AlgebraSolution => {
  try {
    const steps: Step[] = [];
    
    steps.push({
      description: "Original expression",
      expression: expression,
    });

    const parsed = math.parse(expression);
    // Use simplification rules to expand
    const expanded = math.simplify(parsed, [
      { l: '(n1*n2)^n3', r: 'n1^n3 * n2^n3' },
      { l: 'n1^(n2+n3)', r: 'n1^n2 * n1^n3' }
    ]);
    
    steps.push({
      description: "Expand the expression",
      expression: expanded.toString(),
    });

    return {
      steps,
      answer: expanded.toString(),
    };
  } catch (error) {
    throw new Error("Could not expand expression. Please check your input.");
  }
};
